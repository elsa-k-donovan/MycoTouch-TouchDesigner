#include <PololuLedStrip.h>

bool PololuLedStripBase::interruptFriendly = false;